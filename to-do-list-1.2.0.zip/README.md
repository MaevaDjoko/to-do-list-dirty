# to-do-list app
To-Do-List application built with django to Create, Update and Delete tasks.
<br>
<br>
![todolist](https://user-images.githubusercontent.com/65074901/125083144-a5e03900-e0e5-11eb-9092-da716a30a5f3.JPG)
Versioning:
- Le fichier settings.py contient la variable VERSION qui correspond au numéro de version de notre app. Ils suivent le format MAJEUR.MINEUR.PATCH
- si fix, changer PATCH, si feature, changer MINEUR, si breaking change, changer MAJEUR
Commit:
- Chaque nouvelle version est commit avec pour nom Release 'numéro de version'